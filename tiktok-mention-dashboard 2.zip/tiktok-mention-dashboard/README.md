# TikTok Mention Finder — SocialCrawl

Dashboard sederhana untuk endpoint resmi SocialCrawl `GET /v1/tiktok/search/mentions`.

## Menjalankan di komputer
1. Install Node.js 18 atau lebih baru.
2. Ekstrak ZIP, buka terminal pada folder project.
3. Jalankan `npm install`.
4. Jalankan `npm start`.
5. Buka `http://localhost:3000`.
6. Masukkan username `rrs_196` dan API Key SocialCrawl, lalu tekan **Cari mention**.

API key tidak disimpan di localStorage atau file project. Browser mengirimkannya ke server lokal melalui endpoint proxy.

## Fitur
- Pencarian username dengan/ tanpa `@`.
- Hasil video, username pengunggah, caption, waktu, link video.
- Label `mention` atau `link` sesuai `match_kind` dari SocialCrawl.
- Pagination menggunakan `data.next_cursor`.
- Menampilkan kredit terpakai dan saldo kredit jika tersedia.

## Catatan
- Per halaman, SocialCrawl menjalankan dua pencarian internal; biaya maksimal 2 kredit, cache hit dapat 0 kredit.
- API ini mencari konten publik yang ditemukan oleh indeks TikTok; bukan jaminan seluruh video TikTok.
- Endpoint ini tidak memberikan pemantauan push real-time. Untuk memantau konten baru, perlu scheduler yang memanggil halaman pertama berkala dan menyimpan ID video yang sudah dilihat.
- Jangan masukkan API key ke situs publik yang tidak dipercaya. Jika deploy ke hosting, simpan key sebagai environment secret di server, bukan di kode frontend.
