const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/mentions', async (req, res) => {
  try {
    const { handle, apiKey, cursor } = req.body || {};
    if (!handle || !apiKey) return res.status(400).json({ error: 'Username TikTok dan SocialCrawl API Key wajib diisi.' });
    const cleanHandle = String(handle).trim().replace(/^@/, '');
    if (!/^[A-Za-z0-9._]{2,24}$/.test(cleanHandle)) return res.status(400).json({ error: 'Format username TikTok tidak valid.' });
    const url = new URL('https://www.socialcrawl.dev/v1/tiktok/search/mentions');
    url.searchParams.set('handle', cleanHandle);
    if (cursor) url.searchParams.set('cursor', cursor);
    const upstream = await fetch(url, { headers: { 'x-api-key': String(apiKey).trim(), 'accept': 'application/json' } });
    const body = await upstream.json();
    res.status(upstream.status).json(body);
  } catch (err) {
    res.status(502).json({ error: 'Tidak dapat menghubungi SocialCrawl. Periksa koneksi lalu coba lagi.', detail: err.message });
  }
});
app.listen(PORT, () => console.log(`TikTok Mention Dashboard running at http://localhost:${PORT}`));
